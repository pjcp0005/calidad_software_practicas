var searchData=
[
  ['data_0',['data',['../class_lista_enlazada_1_1_iterator.html#a5a1e1d43a78185d3ec1e59e47fed9190',1,'ListaEnlazada::Iterator']]],
  ['de_20carpetas_1',['📁 Descripción de carpetas',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['de_20sonarqube_2',['Warnings de SonarQube',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['del_20compilador_20gcc_20corregidos_3',['Warnings del compilador GCC (corregidos)',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['del_20proyecto_4',['🗂️ Estructura del proyecto',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['descripción_20de_20carpetas_5',['📁 Descripción de carpetas',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
