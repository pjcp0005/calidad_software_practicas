var searchData=
[
  ['pamedicamento_0',['PaMedicamento',['../class_pa_medicamento.html',1,'PaMedicamento'],['../class_pa_medicamento.html#a9e582a7babc37dd7999c2df8d371e844',1,'PaMedicamento::PaMedicamento()'],['../class_pa_medicamento.html#a5b7ae106d5920bfce5ce94cb60a6c054',1,'PaMedicamento::PaMedicamento(int id_num, std::string_view id_alpha, std::string_view name)']]],
  ['pamedicamento_2ecpp_1',['PaMedicamento.cpp',['../_pa_medicamento_8cpp.html',1,'']]],
  ['pamedicamento_2eh_2',['PaMedicamento.h',['../_pa_medicamento_8h.html',1,'']]],
  ['practica2listas_3',['📦 Proyecto: Practica2Listas',['../md__r_e_a_d_m_e.html',1,'']]],
  ['proyecto_4',['🗂️ Estructura del proyecto',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['proyecto_3a_20practica2listas_5',['📦 Proyecto: Practica2Listas',['../md__r_e_a_d_m_e.html',1,'']]]
];
