var searchData=
[
  ['cerr_5fbuffer_0',['cerr_buffer',['../class_simulation_test.html#a52992f5d0f9d9d9d01aba46f33e77599',1,'SimulationTest']]],
  ['cout_5fbuffer_1',['cout_buffer',['../class_simulation_test.html#abed15ad47cab183579065af2dd60081e',1,'SimulationTest']]]
];
