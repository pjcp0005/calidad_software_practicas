var searchData=
[
  ['core_5flogic_2ecpp_0',['core_logic.cpp',['../core__logic_8cpp.html',1,'']]],
  ['core_5flogic_2eh_1',['core_logic.h',['../core__logic_8h.html',1,'']]]
];
