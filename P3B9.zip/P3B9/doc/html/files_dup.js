var files_dup =
[
    [ "include", "dir_77b521970da183c8075d00f7330d8073.html", "dir_77b521970da183c8075d00f7330d8073" ],
    [ "PXB9", "dir_ec306c81fff0ba3a54b9fb94a7d56439.html", "dir_ec306c81fff0ba3a54b9fb94a7d56439" ],
    [ "src", "dir_74ec20e34b548877eacda2cfa7d47598.html", "dir_74ec20e34b548877eacda2cfa7d47598" ],
    [ "tests", "dir_4b0cdea424a34f7430fe77c01e75ef62.html", "dir_4b0cdea424a34f7430fe77c01e75ef62" ]
];